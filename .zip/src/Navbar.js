import React from "react";

class Navbar extends React.Component {
    
    render(){
        return (
            <div className="nav">
                <h2>Dish Tracker</h2>
            </div>

          );
    }
}

export default Navbar;
