import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Doughnut } from 'react-chartjs-2';
import { action } from './data';

ChartJS.register(ArcElement, Tooltip, Legend);

const data = {
  labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
  datasets: [
    {
      label: 'Total',
      data: [12, 19, 3, 5, 2, 3, 5,9,10,3,11],
      backgroundColor: [
        'rgba(138, 63, 252, 0.2)',
        'rgba(255, 126, 182, 0.2)',
        'rgba(111, 220, 140, 0.2)',  
        'rgba(210, 161, 6, 0.2)',
        'rgba(186, 78, 0, 0.2)',
        'rgba(51, 177, 255, 0.2)',
        'rgba(250, 77, 86, 0.2)',
        'rgba(8, 189, 186, 0.2)',
        'rgba(212, 187, 255, 0.2)',
        'rgba(209, 39, 113, 0.2)',
        'rgba(186, 230, 255, 0.2)'
      ],
      borderColor: [
        'rgba(138, 63, 252, 1)',
        'rgba(255, 126, 182, 1)',
        'rgba(111, 220, 140, 1)',  
        'rgba(210, 161, 6, 1)',
        'rgba(186, 78, 0, 1)',
        'rgba(51, 177, 255, 1)',
        'rgba(250, 77, 86, 1)',
        'rgba(8, 189, 186, 1)',
        'rgba(212, 187, 255, 1)',
        'rgba(209, 39, 113, 1)',
        'rgba(186, 230, 255, 1)'
      ],
      borderWidth: 1,
    },
  ],
};

export function DataChart({dataForChart}) {
  console.log('dataForChart=', dataForChart);
  return(<div className='DataChart'>
   <Doughnut data={dataForChart} />
   </div>);
}
